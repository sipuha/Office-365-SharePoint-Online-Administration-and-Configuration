$sites = Import-Csv c:\labs\content\createSites.csv
$root = "https://<tenant>.sharepoint.com/sites/"

foreach($site in $sites) {
    New-SPOSite -url ($root+$site.url) -Owner $site.owner -StorageQuota $site.storage -Title $site.title -Template $site.template -NoWait
    Write-Host "Created site at" ($root+$site.url)
}
